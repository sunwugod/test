# Building

Requirements:
- Java 21 JDK
- Gradle available on PATH
- Internet access for the first Gradle dependency download

Windows PowerShell:
```powershell
.\build.ps1
```

Linux/macOS:
```bash
chmod +x build.sh
./build.sh
```

Or directly:
```bash
gradle build
```

Output:
`build/libs/bewitchment-enemies-1.21.1-1.0.0.jar` (exact Gradle archive naming may vary slightly).

For Minecraft, install Fabric Loader and Fabric API for 1.21.1, then place the built jar in the instance's `mods` folder.
