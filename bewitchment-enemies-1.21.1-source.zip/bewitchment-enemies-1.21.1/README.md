# Bewitchment Enemies — Fabric 1.21.1 conversion

A stripped, standalone 1.21.1 Fabric conversion focused only on Bewitchment's enemy mobs requested for this private port.

## Included mobs

Natural spawns:
- Ghost
- Vampire
- Werewolf
- Hellhound

Spawn egg / command only (no ritual or summoning system):
- Demon
- Leonard
- Baphomet
- Lilith
- Herne

## Preserved / reimplemented

- entity registration and spawn eggs
- natural biome spawning for Ghost, Vampire, Werewolf and Hellhound
- new-moon Vampire condition and full-moon Werewolf condition
- visual variants/textures
- entity models and renderers
- entity sounds
- AI and attributes
- loot tables and the minimum loot/combat items they reference
- Ghost debuffs needed by its variants
- Werewolf return-to-villager behavior
- boss combat AI/minion attacks

## Removed

Rituals, altars, demon summoning/progression, player vampire/werewolf transformations, pledges/contracts, familiars, witchcraft systems, blocks/plants/worldgen, books, unrelated equipment, trinkets, and other unrelated Bewitchment content.

## Build target

- Minecraft 1.21.1
- Fabric Loader 0.16.14+
- Fabric API 0.116.15+1.21.1
- Java 21

Run `gradle build` (or use `build.ps1` / `build.sh`) from the project directory. The resulting mod jar will be under `build/libs/`.

## Important status

This workspace does not have Gradle/Minecraft/Fabric dependencies installed and cannot download the full build toolchain, so the source has **not been compile-tested or launched in Minecraft here**. Java source was syntax-parsed locally, resources were validated for JSON structure/references, and the 1.21.1 API shapes used by the port were checked against Fabric/Yarn documentation.

The four core naturally spawning mobs are the highest-fidelity part of this first pass. The named boss model classes are 1.21.1-safe reconstructions using the original textures and characteristic geometry rather than guaranteed byte-for-byte ports of every original model cube. See `PORT_NOTES.md`.

## Licensing

The supplied Bewitchment jar declares All Rights Reserved. `LICENSE-BEWITCHMENT.txt` is retained. Treat this as a private compatibility port unless you obtain permission to redistribute the original assets/code.
