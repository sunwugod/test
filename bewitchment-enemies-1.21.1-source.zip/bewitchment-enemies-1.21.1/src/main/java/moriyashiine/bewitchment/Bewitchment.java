package moriyashiine.bewitchment;

import moriyashiine.bewitchment.common.registry.BWEntityTypes;
import moriyashiine.bewitchment.common.registry.BWObjects;
import moriyashiine.bewitchment.common.registry.BWSounds;
import moriyashiine.bewitchment.common.registry.BWStatusEffects;
import moriyashiine.bewitchment.common.world.BWWorldSpawns;
import net.fabricmc.api.ModInitializer;
import net.minecraft.util.Identifier;

public class Bewitchment implements ModInitializer {
    public static final String MODID = "bewitchment";

    public static Identifier id(String path) {
        return Identifier.of(MODID, path);
    }

    @Override
    public void onInitialize() {
        BWSounds.init();
        BWStatusEffects.init();
        BWEntityTypes.init();
        BWObjects.init();
        BWWorldSpawns.init();
    }
}
