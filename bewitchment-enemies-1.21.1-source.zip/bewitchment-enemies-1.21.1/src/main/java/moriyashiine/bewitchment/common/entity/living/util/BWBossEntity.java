package moriyashiine.bewitchment.common.entity.living.util;
import net.minecraft.sound.SoundEvents;

import moriyashiine.bewitchment.common.registry.BWSounds;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.ai.goal.ActiveTargetGoal;
import net.minecraft.entity.ai.goal.LookAroundGoal;
import net.minecraft.entity.ai.goal.LookAtEntityGoal;
import net.minecraft.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.entity.ai.goal.RevengeGoal;
import net.minecraft.entity.ai.goal.WanderAroundFarGoal;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerBossBar;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;
import net.minecraft.util.math.MathHelper;
import net.minecraft.world.BossBar;
import net.minecraft.world.World;

public abstract class BWBossEntity extends BWHostileEntity {
    protected final ServerBossBar bossBar;
    protected int rangedCooldown;
    protected int summonCooldown;
    protected int teleportCooldown;

    protected BWBossEntity(EntityType<? extends BWBossEntity> type, World world, BossBar.Color color) {
        super(type, world);
        this.experiencePoints = getBossExperience();
        this.bossBar = new ServerBossBar(getDisplayName(), color, BossBar.Style.PROGRESS);
        this.setPersistent();
    }

    protected int getBossExperience() {
        return 50;
    }

    @Override
    protected void initGoals() {
        goalSelector.add(2, new MeleeAttackGoal(this, 1.0D, false));
        goalSelector.add(5, new WanderAroundFarGoal(this, 0.8D));
        goalSelector.add(6, new LookAtEntityGoal(this, PlayerEntity.class, 12.0F));
        goalSelector.add(7, new LookAroundGoal(this));
        targetSelector.add(1, new RevengeGoal(this));
        targetSelector.add(2, new ActiveTargetGoal<>(this, PlayerEntity.class, true));
    }

    @Override
    public void tick() {
        super.tick();
        if (!getWorld().isClient()) {
            bossBar.setPercent(getHealth() / getMaxHealth());
            LivingEntity target = getTarget();
            if (target == null || !target.isAlive()) {
                if (getHealth() < getMaxHealth()) {
                    heal(idleHealAmount());
                }
                return;
            }

            if (passiveHealInterval() > 0 && age % passiveHealInterval() == 0 && getHealth() < getMaxHealth()) {
                heal(passiveHealAmount());
            }

            if (++rangedCooldown >= rangedInterval()) {
                rangedCooldown = 0;
                performRangedAttack(target);
            }
            if (++summonCooldown >= summonInterval()) {
                summonCooldown = 0;
                summonMinions((ServerWorld) getWorld(), target);
            }
            if (++teleportCooldown >= 600) {
                teleportCooldown = 0;
                teleportNear(target);
            }
        }
    }

    protected float idleHealAmount() {
        return 8.0F;
    }

    protected int passiveHealInterval() {
        return 0;
    }

    protected float passiveHealAmount() {
        return 1.0F;
    }

    protected abstract int rangedInterval();
    protected abstract int summonInterval();
    protected abstract void performRangedAttack(LivingEntity target);
    protected abstract void summonMinions(ServerWorld world, LivingEntity target);

    protected void teleportNear(LivingEntity target) {
        for (int attempt = 0; attempt < 12; attempt++) {
            double x = target.getX() + (random.nextDouble() - 0.5D) * 12.0D;
            double y = target.getY() + random.nextInt(7) - 3;
            double z = target.getZ() + (random.nextDouble() - 0.5D) * 12.0D;
            y = MathHelper.clamp(y, getWorld().getBottomY() + 1, getWorld().getTopY() - 2);
            requestTeleport(x, y, z);
            playSound(SoundEvents.ENTITY_ENDERMAN_TELEPORT, 1.0F, 1.0F);
            break;
        }
    }

    @Override
    public boolean tryAttack(net.minecraft.entity.Entity target) {
        boolean result = super.tryAttack(target);
        if (result && target instanceof LivingEntity living) {
            living.setOnFireFor(meleeFireSeconds());
            living.addVelocity(0.0D, 0.2D, 0.0D);
        }
        return result;
    }

    protected int meleeFireSeconds() {
        return 8;
    }

    @Override
    public boolean isFireImmune() {
        return true;
    }

    @Override
    public boolean cannotDespawn() {
        return true;
    }

    @Override
    public boolean handleFallDamage(float fallDistance, float damageMultiplier, net.minecraft.entity.damage.DamageSource damageSource) {
        return false;
    }

    @Override
    public void setCustomName(Text name) {
        super.setCustomName(name);
        bossBar.setName(getDisplayName());
    }

    @Override
    public void onStartedTrackingBy(ServerPlayerEntity player) {
        super.onStartedTrackingBy(player);
        bossBar.addPlayer(player);
    }

    @Override
    public void onStoppedTrackingBy(ServerPlayerEntity player) {
        super.onStoppedTrackingBy(player);
        bossBar.removePlayer(player);
    }
}
