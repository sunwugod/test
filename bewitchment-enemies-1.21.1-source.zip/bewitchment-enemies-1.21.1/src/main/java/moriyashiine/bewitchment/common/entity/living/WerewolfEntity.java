package moriyashiine.bewitchment.common.entity.living;
import net.minecraft.sound.SoundEvents;

import moriyashiine.bewitchment.common.entity.living.util.BWHostileEntity;
import moriyashiine.bewitchment.common.registry.BWSounds;
import net.minecraft.entity.*;
import net.minecraft.entity.ai.goal.*;
import net.minecraft.entity.attribute.DefaultAttributeContainer;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.passive.MerchantEntity;
import net.minecraft.entity.passive.SheepEntity;
import net.minecraft.entity.passive.VillagerEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundEvent;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.random.Random;
import net.minecraft.world.LocalDifficulty;
import net.minecraft.world.ServerWorldAccess;
import net.minecraft.world.World;

public class WerewolfEntity extends BWHostileEntity {
    private NbtCompound storedVillager;

    public WerewolfEntity(EntityType<? extends WerewolfEntity> type, World world) { super(type, world); }

    public static DefaultAttributeContainer.Builder createAttributes() {
        return HostileEntity.createHostileAttributes()
                .add(EntityAttributes.GENERIC_MAX_HEALTH, 20)
                .add(EntityAttributes.GENERIC_ATTACK_DAMAGE, 15)
                .add(EntityAttributes.GENERIC_ARMOR, 20)
                .add(EntityAttributes.GENERIC_ARMOR_TOUGHNESS, 8)
                .add(EntityAttributes.GENERIC_MOVEMENT_SPEED, 0.4)
                .add(EntityAttributes.GENERIC_STEP_HEIGHT, 1.0);
    }

    public static boolean canSpawn(EntityType<WerewolfEntity> type, ServerWorldAccess world, SpawnReason reason, BlockPos pos, Random random) {
        return !world.toServerWorld().isDay() && world.toServerWorld().getMoonPhase() == 0 && HostileEntity.canSpawnInDark(type, world, reason, pos, random);
    }

    @Override public EntityData initialize(ServerWorldAccess world, LocalDifficulty difficulty, SpawnReason reason, EntityData data) {
        EntityData out=super.initialize(world,difficulty,reason,data);
        if (storedVillager==null) {
            VillagerEntity villager=EntityType.VILLAGER.create(world.toServerWorld());
            if (villager!=null) { storedVillager=new NbtCompound(); villager.writeNbt(storedVillager); }
        }
        return out;
    }

    @Override public int getVariants() { return 7; }
    @Override protected boolean hasShiny() { return true; }

    @Override protected void initGoals() {
        goalSelector.add(1,new SwimGoal(this));
        goalSelector.add(2,new MeleeAttackGoal(this,1.0,false));
        goalSelector.add(5,new WanderAroundFarGoal(this,0.8));
        goalSelector.add(6,new LookAtEntityGoal(this,PlayerEntity.class,8));
        goalSelector.add(7,new LookAroundGoal(this));
        targetSelector.add(1,new RevengeGoal(this));
        targetSelector.add(2,new ActiveTargetGoal<>(this, LivingEntity.class,10,true,false,
                e -> e instanceof PlayerEntity || e instanceof SheepEntity || e instanceof MerchantEntity || (e instanceof net.minecraft.entity.mob.MobEntity m && m.getType().isIn(net.minecraft.registry.tag.EntityTypeTags.ILLAGER))));
    }

    @Override public void tick() {
        super.tick();
        if (!getWorld().isClient() && age%20==0 && storedVillager!=null && (getWorld().isDay() || getWorld().getMoonPhase()!=0)) transformBack();
    }

    private void transformBack() {
        if (!(getWorld() instanceof ServerWorld sw)) return;
        VillagerEntity villager=EntityType.VILLAGER.create(sw); if (villager==null) return;
        try { villager.readNbt(storedVillager.copy()); } catch (Exception ignored) {}
        villager.refreshPositionAndAngles(getX(),getY(),getZ(),getYaw(),getPitch());
        villager.setHealth(Math.max(1, Math.min(villager.getMaxHealth(), villager.getMaxHealth()*(getHealth()/getMaxHealth()))));
        if (isOnFire()) villager.setOnFireFor(4);
        for (var effect:getStatusEffects()) villager.addStatusEffect(new net.minecraft.entity.effect.StatusEffectInstance(effect));
        sw.spawnEntity(villager);
        sw.spawnParticles(ParticleTypes.SMOKE,getX(),getBodyY(.5),getZ(),20,.4,.7,.4,.02);
        playSound(SoundEvents.BLOCK_FIRE_EXTINGUISH,1,1);
        discard();
    }

    @Override public void writeCustomDataToNbt(NbtCompound nbt) { super.writeCustomDataToNbt(nbt); if(storedVillager!=null) nbt.put("Villager",storedVillager); }
    @Override public void readCustomDataFromNbt(NbtCompound nbt) { super.readCustomDataFromNbt(nbt); if(nbt.contains("Villager")) storedVillager=nbt.getCompound("Villager"); }
    @Override protected SoundEvent getAmbientSound(){return BWSounds.WEREWOLF_AMBIENT;}
    @Override protected SoundEvent getHurtSound(net.minecraft.entity.damage.DamageSource s){return BWSounds.WEREWOLF_HURT;}
    @Override protected SoundEvent getDeathSound(){return BWSounds.WEREWOLF_DEATH;}
}
