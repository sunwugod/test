package moriyashiine.bewitchment.common.entity.living;

import moriyashiine.bewitchment.common.entity.living.util.BWHostileEntity;
import moriyashiine.bewitchment.common.registry.BWSounds;
import net.minecraft.block.Blocks;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.ai.goal.*;
import net.minecraft.entity.attribute.DefaultAttributeContainer;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.sound.SoundEvent;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.random.Random;
import net.minecraft.world.ServerWorldAccess;
import net.minecraft.world.World;

public class HellhoundEntity extends BWHostileEntity {
    public HellhoundEntity(EntityType<? extends HellhoundEntity> type, World world) { super(type, world); }

    public static DefaultAttributeContainer.Builder createAttributes() {
        return HostileEntity.createHostileAttributes()
                .add(EntityAttributes.GENERIC_MAX_HEALTH, 30)
                .add(EntityAttributes.GENERIC_ATTACK_DAMAGE, 3)
                .add(EntityAttributes.GENERIC_MOVEMENT_SPEED, 0.425);
    }

    public static boolean canSpawn(EntityType<HellhoundEntity> type, ServerWorldAccess world, net.minecraft.entity.SpawnReason reason, BlockPos pos, Random random) {
        return !world.getBlockState(pos.down()).isOf(Blocks.NETHER_WART_BLOCK) && HostileEntity.canSpawnIgnoreLightLevel(type, world, reason, pos, random);
    }

    @Override public int getVariants() { return 5; }
    @Override protected boolean hasShiny() { return true; }

    @Override protected void initGoals() {
        goalSelector.add(1, new SwimGoal(this));
        goalSelector.add(2, new PounceAtTargetGoal(this, 0.4F));
        goalSelector.add(3, new MeleeAttackGoal(this, 1.0D, false));
        goalSelector.add(5, new WanderAroundFarGoal(this, 0.9D));
        goalSelector.add(6, new LookAtEntityGoal(this, PlayerEntity.class, 8));
        goalSelector.add(7, new LookAroundGoal(this));
        targetSelector.add(1, new RevengeGoal(this));
        targetSelector.add(2, new ActiveTargetGoal<>(this, PlayerEntity.class, true));
    }

    @Override public boolean tryAttack(net.minecraft.entity.Entity target) {
        boolean hit = super.tryAttack(target);
        if (hit && target instanceof LivingEntity living) living.setOnFireFor(3);
        return hit;
    }

    @Override public void tickMovement() {
        super.tickMovement();
        if (!getWorld().isClient() && isWet() && age % 20 == 0) damage(getDamageSources().magic(), 1.0F);
    }

    @Override protected SoundEvent getAmbientSound() { return BWSounds.HELLHOUND_AMBIENT; }
    @Override protected SoundEvent getHurtSound(net.minecraft.entity.damage.DamageSource source) { return BWSounds.HELLHOUND_HURT; }
    @Override protected SoundEvent getDeathSound() { return BWSounds.HELLHOUND_DEATH; }
}
