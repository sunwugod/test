package moriyashiine.bewitchment.common.entity.living;
import net.minecraft.sound.SoundEvents;

import moriyashiine.bewitchment.common.entity.living.util.BWHostileEntity;
import moriyashiine.bewitchment.common.registry.BWSounds;
import net.minecraft.entity.*;
import net.minecraft.entity.ai.goal.*;
import net.minecraft.entity.attribute.*;
import net.minecraft.entity.data.*;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.projectile.SmallFireballEntity;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.sound.SoundEvent;
import net.minecraft.world.World;

public class DemonEntity extends BWHostileEntity {
    public static final TrackedData<Boolean> MALE=DataTracker.registerData(DemonEntity.class,TrackedDataHandlerRegistry.BOOLEAN);
    public DemonEntity(EntityType<? extends DemonEntity> type, World world){super(type,world);experiencePoints=20;}
    public static DefaultAttributeContainer.Builder createAttributes(){return HostileEntity.createHostileAttributes().add(EntityAttributes.GENERIC_MAX_HEALTH,200).add(EntityAttributes.GENERIC_ATTACK_DAMAGE,6).add(EntityAttributes.GENERIC_ARMOR,4).add(EntityAttributes.GENERIC_MOVEMENT_SPEED,.25).add(EntityAttributes.GENERIC_KNOCKBACK_RESISTANCE,.75);}
    @Override protected void initDataTracker(DataTracker.Builder b){super.initDataTracker(b);b.add(MALE,true);}
    @Override public EntityData initialize(net.minecraft.world.ServerWorldAccess w,net.minecraft.world.LocalDifficulty d,SpawnReason r,EntityData data){EntityData out=super.initialize(w,d,r,data);dataTracker.set(MALE,random.nextBoolean());return out;}
    @Override public int getVariants(){return 5;} @Override protected boolean hasShiny(){return true;} public boolean isMale(){return dataTracker.get(MALE);}
    @Override protected void initGoals(){goalSelector.add(1,new SwimGoal(this));goalSelector.add(2,new MeleeAttackGoal(this,1,false));goalSelector.add(5,new WanderAroundFarGoal(this,.8));goalSelector.add(6,new LookAtEntityGoal(this,PlayerEntity.class,12));goalSelector.add(7,new LookAroundGoal(this));targetSelector.add(1,new RevengeGoal(this));targetSelector.add(2,new ActiveTargetGoal<>(this,PlayerEntity.class,true));}
    @Override public void tick(){super.tick();if(!getWorld().isClient()&&getTarget()!=null&&age%40==0){LivingEntity t=getTarget();double dx=t.getX()-getX(),dy=t.getBodyY(.5)-getBodyY(.5),dz=t.getZ()-getZ();SmallFireballEntity f=new SmallFireballEntity(getWorld(),this,new net.minecraft.util.math.Vec3d(dx,dy,dz).normalize());f.setPosition(getX(),getBodyY(.6),getZ());getWorld().spawnEntity(f);playSound(SoundEvents.ENTITY_GHAST_SHOOT,1,1);swingHand(Hand.MAIN_HAND);}}
    @Override public boolean tryAttack(Entity target){boolean hit=super.tryAttack(target);if(hit&&target instanceof LivingEntity l){l.setOnFireFor(6);l.addVelocity(0,.2,0);}return hit;}
    @Override public void writeCustomDataToNbt(NbtCompound n){super.writeCustomDataToNbt(n);n.putBoolean("Male",isMale());} @Override public void readCustomDataFromNbt(NbtCompound n){super.readCustomDataFromNbt(n);if(n.contains("Male"))dataTracker.set(MALE,n.getBoolean("Male"));}
    @Override protected SoundEvent getAmbientSound(){return BWSounds.DEMON_AMBIENT;} @Override protected SoundEvent getHurtSound(net.minecraft.entity.damage.DamageSource s){return BWSounds.DEMON_HURT;} @Override protected SoundEvent getDeathSound(){return BWSounds.DEMON_DEATH;}
}
