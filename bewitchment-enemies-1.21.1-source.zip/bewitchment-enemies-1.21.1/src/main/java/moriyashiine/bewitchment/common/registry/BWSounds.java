package moriyashiine.bewitchment.common.registry;

import moriyashiine.bewitchment.Bewitchment;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.sound.SoundEvent;

public final class BWSounds {
    private BWSounds() {}

    public static final SoundEvent GHOST_AMBIENT = register("entity.ghost.ambient");
    public static final SoundEvent GHOST_HURT = register("entity.ghost.hurt");
    public static final SoundEvent GHOST_DEATH = register("entity.ghost.death");
    public static final SoundEvent VAMPIRE_AMBIENT = register("entity.vampire.ambient");
    public static final SoundEvent VAMPIRE_HURT = register("entity.vampire.hurt");
    public static final SoundEvent VAMPIRE_DEATH = register("entity.vampire.death");
    public static final SoundEvent WEREWOLF_AMBIENT = register("entity.werewolf.ambient");
    public static final SoundEvent WEREWOLF_HURT = register("entity.werewolf.hurt");
    public static final SoundEvent WEREWOLF_DEATH = register("entity.werewolf.death");
    public static final SoundEvent HELLHOUND_AMBIENT = register("entity.hellhound.ambient");
    public static final SoundEvent HELLHOUND_HURT = register("entity.hellhound.hurt");
    public static final SoundEvent HELLHOUND_DEATH = register("entity.hellhound.death");
    public static final SoundEvent DEMON_AMBIENT = register("entity.demon.ambient");
    public static final SoundEvent DEMON_HURT = register("entity.demon.hurt");
    public static final SoundEvent DEMON_DEATH = register("entity.demon.death");
    public static final SoundEvent LEONARD_AMBIENT = register("entity.leonard.ambient");
    public static final SoundEvent LEONARD_HURT = register("entity.leonard.hurt");
    public static final SoundEvent LEONARD_DEATH = register("entity.leonard.death");
    public static final SoundEvent BAPHOMET_AMBIENT = register("entity.baphomet.ambient");
    public static final SoundEvent BAPHOMET_HURT = register("entity.baphomet.hurt");
    public static final SoundEvent BAPHOMET_DEATH = register("entity.baphomet.death");
    public static final SoundEvent LILITH_AMBIENT = register("entity.lilith.ambient");
    public static final SoundEvent LILITH_HURT = register("entity.lilith.hurt");
    public static final SoundEvent LILITH_DEATH = register("entity.lilith.death");
    public static final SoundEvent HERNE_AMBIENT = register("entity.herne.ambient");
    public static final SoundEvent HERNE_HURT = register("entity.herne.hurt");
    public static final SoundEvent HERNE_DEATH = register("entity.herne.death");

    private static SoundEvent register(String name) {
        var id = Bewitchment.id(name);
        return Registry.register(Registries.SOUND_EVENT, id, SoundEvent.of(id));
    }

    public static void init() {}
}
