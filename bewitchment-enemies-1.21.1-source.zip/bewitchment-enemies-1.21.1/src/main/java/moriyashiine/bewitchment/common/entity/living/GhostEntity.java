package moriyashiine.bewitchment.common.entity.living;

import moriyashiine.bewitchment.common.entity.living.util.BWHostileEntity;
import moriyashiine.bewitchment.common.registry.BWSounds;
import moriyashiine.bewitchment.common.registry.BWStatusEffects;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.ai.control.MoveControl;
import net.minecraft.entity.ai.goal.*;
import net.minecraft.entity.attribute.DefaultAttributeContainer;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.data.DataTracker;
import net.minecraft.entity.data.TrackedData;
import net.minecraft.entity.data.TrackedDataHandlerRegistry;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.sound.SoundEvent;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.math.random.Random;
import net.minecraft.world.ServerWorldAccess;
import net.minecraft.world.World;

import java.util.EnumSet;

public class GhostEntity extends BWHostileEntity {
    public static final TrackedData<Boolean> HAS_TARGET = DataTracker.registerData(GhostEntity.class, TrackedDataHandlerRegistry.BOOLEAN);

    public GhostEntity(EntityType<? extends GhostEntity> type, World world) {
        super(type, world); setNoGravity(true); moveControl = new GhostMoveControl(this);
    }

    public static DefaultAttributeContainer.Builder createAttributes() {
        return HostileEntity.createHostileAttributes()
                .add(EntityAttributes.GENERIC_MAX_HEALTH, 20)
                .add(EntityAttributes.GENERIC_FLYING_SPEED, 0.25)
                .add(EntityAttributes.GENERIC_KNOCKBACK_RESISTANCE, 1)
                .add(EntityAttributes.GENERIC_FOLLOW_RANGE, 8);
    }

    public static boolean canSpawn(EntityType<GhostEntity> type, ServerWorldAccess world, net.minecraft.entity.SpawnReason reason, BlockPos pos, Random random) {
        return HostileEntity.canSpawnInDark(type, world, reason, pos, random);
    }

    @Override protected void initDataTracker(DataTracker.Builder builder) { super.initDataTracker(builder); builder.add(HAS_TARGET, false); }
    @Override public int getVariants() { return 5; }
    @Override protected boolean hasShiny() { return true; }

    @Override protected void initGoals() {
        goalSelector.add(1, new SwimGoal(this));
        goalSelector.add(4, new FlyRandomlyGoal(this));
        goalSelector.add(6, new LookAtEntityGoal(this, PlayerEntity.class, 8));
        goalSelector.add(7, new LookAroundGoal(this));
        targetSelector.add(1, new RevengeGoal(this));
        targetSelector.add(2, new ActiveTargetGoal<>(this, PlayerEntity.class, true));
    }

    @Override public void tick() {
        noClip = true; super.tick(); noClip = true; setNoGravity(true);
        if (!getWorld().isClient()) {
            LivingEntity target = getTarget();
            if (target != null && target.isAlive() && age % 20 == 0) {
                int v = getVariant() == 0 ? 1 + random.nextInt(4) : getVariant();
                switch (v) {
                    case 1 -> target.addStatusEffect(new StatusEffectInstance(StatusEffects.HUNGER, 100));
                    case 2 -> target.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, 100));
                    case 3 -> target.addStatusEffect(new StatusEffectInstance(BWStatusEffects.CORROSION, 100));
                    default -> target.addStatusEffect(new StatusEffectInstance(BWStatusEffects.SINKING, 100));
                }
            }
            if (!hasCustomName() && getWorld().isDay() && !getWorld().isRaining() && getWorld().isSkyVisible(getBlockPos())) {
                if (getWorld() instanceof net.minecraft.server.world.ServerWorld sw) sw.spawnParticles(ParticleTypes.SMOKE, getX(), getBodyY(0.5), getZ(), 8, 0.2, 0.4, 0.2, 0.01);
                discard();
            }
        }
    }

    @Override public void setTarget(LivingEntity target) { super.setTarget(target); dataTracker.set(HAS_TARGET, target != null); }
    @Override public boolean canHaveStatusEffect(StatusEffectInstance effect) { return false; }
    @Override public boolean isPushable() { return false; }
    @Override protected SoundEvent getAmbientSound() { return BWSounds.GHOST_AMBIENT; }
    @Override protected SoundEvent getHurtSound(net.minecraft.entity.damage.DamageSource source) { return BWSounds.GHOST_HURT; }
    @Override protected SoundEvent getDeathSound() { return BWSounds.GHOST_DEATH; }

    static class FlyRandomlyGoal extends Goal {
        private final GhostEntity ghost;
        FlyRandomlyGoal(GhostEntity ghost) { this.ghost = ghost; setControls(EnumSet.of(Control.MOVE)); }
        @Override public boolean canStart() { return !ghost.getMoveControl().isMoving() && ghost.random.nextInt(7) == 0; }
        @Override public boolean shouldContinue() { return ghost.getMoveControl().isMoving(); }
        @Override public void start() {
            for (int i=0;i<8;i++) {
                double x=ghost.getX()+ghost.random.nextInt(15)-7, y=ghost.getY()+ghost.random.nextInt(11)-5, z=ghost.getZ()+ghost.random.nextInt(15)-7;
                if (ghost.getWorld().isAir(BlockPos.ofFloored(x,y,z))) { ghost.getMoveControl().moveTo(x,y,z,1.0); return; }
            }
        }
    }
    static class GhostMoveControl extends MoveControl {
        private final GhostEntity ghost;
        GhostMoveControl(GhostEntity ghost) { super(ghost); this.ghost=ghost; }
        @Override public void tick() {
            if (state == State.MOVE_TO) {
                Vec3d d = new Vec3d(targetX-ghost.getX(), targetY-ghost.getY(), targetZ-ghost.getZ());
                double len=d.length(); if (len < ghost.getBoundingBox().getAverageSideLength()) { state=State.WAIT; ghost.setVelocity(ghost.getVelocity().multiply(0.5)); return; }
                ghost.setVelocity(ghost.getVelocity().add(d.multiply(speed * 0.05 / len)));
                if (ghost.getTarget()!=null) ghost.setYaw((float)(-MathHelper.atan2(ghost.getVelocity().x, ghost.getVelocity().z)*57.295776F));
                else ghost.setYaw((float)(-MathHelper.atan2(d.x,d.z)*57.295776F));
                ghost.bodyYaw=ghost.getYaw();
            }
        }
    }
}
