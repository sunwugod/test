package moriyashiine.bewitchment.common.registry;

import moriyashiine.bewitchment.Bewitchment;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.attribute.EntityAttributeModifier;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.effect.StatusEffect;
import net.minecraft.entity.effect.StatusEffectCategory;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.util.math.Vec3d;

public final class BWStatusEffects {
    private BWStatusEffects() {}

    public static final RegistryEntry.Reference<StatusEffect> CORROSION = Registry.registerReference(
            Registries.STATUS_EFFECT, Bewitchment.id("corrosion"),
            new BasicEffect(StatusEffectCategory.HARMFUL, 0x597045)
                    .addAttributeModifier(EntityAttributes.GENERIC_ARMOR, Bewitchment.id("corrosion"), -3.0, EntityAttributeModifier.Operation.ADD_VALUE));

    public static final RegistryEntry.Reference<StatusEffect> HARDENING = Registry.registerReference(
            Registries.STATUS_EFFECT, Bewitchment.id("hardening"),
            new BasicEffect(StatusEffectCategory.BENEFICIAL, 0x96765A)
                    .addAttributeModifier(EntityAttributes.GENERIC_ARMOR, Bewitchment.id("hardening"), 3.0, EntityAttributeModifier.Operation.ADD_VALUE));

    public static final RegistryEntry.Reference<StatusEffect> SINKING = Registry.registerReference(
            Registries.STATUS_EFFECT, Bewitchment.id("sinking"), new SinkingEffect());

    public static final RegistryEntry.Reference<StatusEffect> MORTAL_COIL = Registry.registerReference(
            Registries.STATUS_EFFECT, Bewitchment.id("mortal_coil"), new MortalCoilEffect());

    public static void init() {}

    private static class BasicEffect extends StatusEffect {
        protected BasicEffect(StatusEffectCategory category, int color) {
            super(category, color);
        }
    }

    private static class SinkingEffect extends StatusEffect {
        protected SinkingEffect() {
            super(StatusEffectCategory.HARMFUL, 0x3C4858);
        }

        @Override
        public boolean canApplyUpdateEffect(int duration, int amplifier) {
            return true;
        }

        @Override
        public boolean applyUpdateEffect(LivingEntity entity, int amplifier) {
            double amount = 0.05D * (amplifier + 1);
            Vec3d velocity = entity.getVelocity();
            if (velocity.y < 0) {
                entity.setVelocity(velocity.x, velocity.y * (1.0D + amount), velocity.z);
            }
            if (entity.isTouchingWater() || entity.isFallFlying()) {
                entity.addVelocity(0.0D, -amount / 2.0D, 0.0D);
            }
            return true;
        }
    }

    private static class MortalCoilEffect extends StatusEffect {
        protected MortalCoilEffect() {
            super(StatusEffectCategory.HARMFUL, 0x341D36);
        }

        @Override
        public boolean canApplyUpdateEffect(int duration, int amplifier) {
            return duration == 1;
        }

        @Override
        public boolean applyUpdateEffect(LivingEntity entity, int amplifier) {
            entity.damage(entity.getDamageSources().magic(), Float.MAX_VALUE);
            return true;
        }
    }
}
