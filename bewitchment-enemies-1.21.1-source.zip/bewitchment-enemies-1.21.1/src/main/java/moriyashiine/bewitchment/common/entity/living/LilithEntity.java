package moriyashiine.bewitchment.common.entity.living;

import moriyashiine.bewitchment.common.entity.living.util.BWBossEntity;
import moriyashiine.bewitchment.common.registry.BWEntityTypes;
import moriyashiine.bewitchment.common.registry.BWSounds;
import moriyashiine.bewitchment.common.registry.BWStatusEffects;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.attribute.DefaultAttributeContainer;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.projectile.WitherSkullEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundEvent;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.BossBar;
import net.minecraft.world.World;

public class LilithEntity extends BWBossEntity {
    public LilithEntity(EntityType<? extends LilithEntity> type, World world) {
        super(type, world, BossBar.Color.RED);
    }

    public static DefaultAttributeContainer.Builder createAttributes() {
        return HostileEntity.createHostileAttributes()
                .add(EntityAttributes.GENERIC_MAX_HEALTH, 500)
                .add(EntityAttributes.GENERIC_ATTACK_DAMAGE, 16)
                .add(EntityAttributes.GENERIC_ARMOR, 10)
                .add(EntityAttributes.GENERIC_MOVEMENT_SPEED, 0.3)
                .add(EntityAttributes.GENERIC_KNOCKBACK_RESISTANCE, 1)
                .add(EntityAttributes.GENERIC_FOLLOW_RANGE, 32);
    }

    @Override public int getVariants() { return 1; }
    @Override protected int getBossExperience() { return 75; }
    @Override protected int passiveHealInterval() { return 10; }
    @Override protected int rangedInterval() { return 40; }
    @Override protected int summonInterval() { return 600; }
    @Override protected int meleeFireSeconds() { return 16; }

    @Override
    protected void performRangedAttack(LivingEntity target) {
        for (int i = -1; i <= 1; i++) {
            Vec3d velocity = new Vec3d(
                    target.getX() - getX() + i * 0.75D,
                    target.getBodyY(0.5D) - getBodyY(0.65D),
                    target.getZ() - getZ()).normalize();
            WitherSkullEntity skull = new WitherSkullEntity(getWorld(), this, velocity);
            skull.setPosition(getX(), getBodyY(0.65D), getZ());
            getWorld().spawnEntity(skull);
        }
        playSound(BWSounds.GENERIC_SHOOT, 1.0F, 1.0F);
    }

    @Override
    protected void summonMinions(ServerWorld world, LivingEntity target) {
        for (int i = 0; i < 3; i++) {
            VampireEntity vampire = BWEntityTypes.VAMPIRE.create(world);
            if (vampire != null) {
                vampire.refreshPositionAndAngles(getX() + random.nextInt(7) - 3, getY(), getZ() + random.nextInt(7) - 3, 0.0F, 0.0F);
                vampire.addStatusEffect(new StatusEffectInstance(StatusEffects.STRENGTH, 1200, 1));
                vampire.addStatusEffect(new StatusEffectInstance(StatusEffects.RESISTANCE, 1200, 1));
                vampire.addStatusEffect(new StatusEffectInstance(BWStatusEffects.HARDENING, 1200, 1));
                vampire.setTarget(target);
                world.spawnEntity(vampire);
            }
        }
    }

    @Override
    public boolean tryAttack(Entity target) {
        boolean hit = super.tryAttack(target);
        if (hit && target instanceof LivingEntity living) {
            living.addStatusEffect(new StatusEffectInstance(BWStatusEffects.MORTAL_COIL, 1200));
        }
        return hit;
    }

    @Override
    public void setTarget(LivingEntity target) {
        if (target != null && getWorld().isDay()) target = null;
        super.setTarget(target);
    }

    @Override protected SoundEvent getAmbientSound() { return BWSounds.LILITH_AMBIENT; }
    @Override protected SoundEvent getHurtSound(net.minecraft.entity.damage.DamageSource source) { return BWSounds.LILITH_HURT; }
    @Override protected SoundEvent getDeathSound() { return BWSounds.LILITH_DEATH; }
}
