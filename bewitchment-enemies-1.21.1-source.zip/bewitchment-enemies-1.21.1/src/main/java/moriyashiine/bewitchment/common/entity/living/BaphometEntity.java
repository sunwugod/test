package moriyashiine.bewitchment.common.entity.living;
import net.minecraft.sound.SoundEvents;

import moriyashiine.bewitchment.common.entity.living.util.BWBossEntity;
import moriyashiine.bewitchment.common.registry.BWSounds;
import moriyashiine.bewitchment.common.registry.BWStatusEffects;
import net.minecraft.entity.*;
import net.minecraft.entity.attribute.*;
import net.minecraft.entity.effect.*;
import net.minecraft.entity.mob.BlazeEntity;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.projectile.SmallFireballEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundEvent;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.BossBar;
import net.minecraft.world.World;

public class BaphometEntity extends BWBossEntity {
    public BaphometEntity(EntityType<? extends BaphometEntity> type,World world){super(type,world,BossBar.Color.YELLOW);}
    public static DefaultAttributeContainer.Builder createAttributes(){return HostileEntity.createHostileAttributes().add(EntityAttributes.GENERIC_MAX_HEALTH,375).add(EntityAttributes.GENERIC_ATTACK_DAMAGE,12).add(EntityAttributes.GENERIC_ARMOR,6).add(EntityAttributes.GENERIC_MOVEMENT_SPEED,.25).add(EntityAttributes.GENERIC_KNOCKBACK_RESISTANCE,.75).add(EntityAttributes.GENERIC_FOLLOW_RANGE,32);}
    @Override public int getVariants(){return 1;} @Override protected int passiveHealInterval(){return 20;} @Override protected int rangedInterval(){return 60;} @Override protected int summonInterval(){return 600;}
    @Override protected void performRangedAttack(LivingEntity target){for(int i=-1;i<=1;i++){Vec3d aim=new Vec3d(target.getX()-getX(),target.getBodyY(.5)-getBodyY(.5)+i*.25,target.getZ()-getZ()).normalize();SmallFireballEntity f=new SmallFireballEntity(getWorld(),this,aim);f.setPosition(getX(),getBodyY(.65),getZ());getWorld().spawnEntity(f);}playSound(SoundEvents.ENTITY_GHAST_SHOOT,1,1);}
    @Override protected void summonMinions(ServerWorld world,LivingEntity target){for(int i=0;i<3;i++){BlazeEntity b=EntityType.BLAZE.create(world);if(b!=null){b.refreshPositionAndAngles(getX()+random.nextInt(7)-3,getY(),getZ()+random.nextInt(7)-3,0,0);b.addStatusEffect(new StatusEffectInstance(StatusEffects.RESISTANCE,1200,1));b.addStatusEffect(new StatusEffectInstance(BWStatusEffects.HARDENING,1200,1));b.setTarget(target);world.spawnEntity(b);}}}
    @Override protected SoundEvent getAmbientSound(){return BWSounds.BAPHOMET_AMBIENT;} @Override protected SoundEvent getHurtSound(net.minecraft.entity.damage.DamageSource s){return BWSounds.BAPHOMET_HURT;} @Override protected SoundEvent getDeathSound(){return BWSounds.BAPHOMET_DEATH;}
}
