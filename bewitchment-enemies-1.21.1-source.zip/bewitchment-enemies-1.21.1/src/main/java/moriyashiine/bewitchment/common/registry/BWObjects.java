package moriyashiine.bewitchment.common.registry;

import moriyashiine.bewitchment.Bewitchment;
import net.minecraft.item.Item;
import net.minecraft.item.SpawnEggItem;
import net.minecraft.item.ItemGroups;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;

public final class BWObjects {
    private BWObjects() {}
    public static final Item ECTOPLASM=item("ectoplasm");
    public static final Item BOTTLE_OF_BLOOD=item("bottle_of_blood");
    public static final Item DEMON_HORN=item("demon_horn");
    public static final Item SNAKE_TONGUE=item("snake_tongue");
    public static final Item DEMON_HEART=item("demon_heart");
    public static final Item SCEPTER=item("scepter",new Item.Settings().maxCount(1));
    public static final Item CADUCEUS=item("caduceus",new Item.Settings().maxCount(1));
    public static final Item HARBINGER=item("harbinger",new Item.Settings().maxCount(1));
    public static final Item HORNED_SPEAR=item("horned_spear",new Item.Settings().maxCount(1).maxDamage(750));

    public static final Item GHOST_SPAWN_EGG=egg("ghost_spawn_egg",BWEntityTypes.GHOST,13290186,9868950);
    public static final Item VAMPIRE_SPAWN_EGG=egg("vampire_spawn_egg",BWEntityTypes.VAMPIRE,14535848,8192000);
    public static final Item WEREWOLF_SPAWN_EGG=egg("werewolf_spawn_egg",BWEntityTypes.WEREWOLF,10459798,5451535);
    public static final Item HELLHOUND_SPAWN_EGG=egg("hellhound_spawn_egg",BWEntityTypes.HELLHOUND,13115392,8396832);
    public static final Item DEMON_SPAWN_EGG=egg("demon_spawn_egg",BWEntityTypes.DEMON,8396832,13115392);
    public static final Item LEONARD_SPAWN_EGG=egg("leonard_spawn_egg",BWEntityTypes.LEONARD,6173204,10486531);
    public static final Item BAPHOMET_SPAWN_EGG=egg("baphomet_spawn_egg",BWEntityTypes.BAPHOMET,10486531,6173204);
    public static final Item LILITH_SPAWN_EGG=egg("lilith_spawn_egg",BWEntityTypes.LILITH,2237985,13224909);
    public static final Item HERNE_SPAWN_EGG=egg("herne_spawn_egg",BWEntityTypes.HERNE,6113325,2706944);

    private static Item item(String id){return item(id,new Item.Settings());}
    private static Item item(String id,Item.Settings settings){return Registry.register(Registries.ITEM,Bewitchment.id(id),new Item(settings));}
    private static Item egg(String id, net.minecraft.entity.EntityType<? extends net.minecraft.entity.mob.MobEntity> type,int a,int b){return Registry.register(Registries.ITEM,Bewitchment.id(id),new SpawnEggItem(type,a,b,new Item.Settings()));}
    public static void init() {
        ItemGroupEvents.modifyEntriesEvent(ItemGroups.SPAWN_EGGS).register(entries -> {
            entries.add(GHOST_SPAWN_EGG); entries.add(VAMPIRE_SPAWN_EGG); entries.add(WEREWOLF_SPAWN_EGG); entries.add(HELLHOUND_SPAWN_EGG);
            entries.add(DEMON_SPAWN_EGG); entries.add(LEONARD_SPAWN_EGG); entries.add(BAPHOMET_SPAWN_EGG); entries.add(LILITH_SPAWN_EGG); entries.add(HERNE_SPAWN_EGG);
        });
    }
}
