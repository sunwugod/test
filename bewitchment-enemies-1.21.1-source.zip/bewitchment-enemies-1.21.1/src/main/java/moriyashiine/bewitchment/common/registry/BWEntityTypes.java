package moriyashiine.bewitchment.common.registry;

import moriyashiine.bewitchment.Bewitchment;
import moriyashiine.bewitchment.common.entity.living.*;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricEntityType;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnGroup;
import net.minecraft.entity.SpawnLocationTypes;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.world.Heightmap;

public final class BWEntityTypes {
    private BWEntityTypes() {}

    public static final EntityType<GhostEntity> GHOST = register("ghost",
            FabricEntityType.Builder.createMob(GhostEntity::new, SpawnGroup.MONSTER,
                            mob -> mob.defaultAttributes(GhostEntity::createAttributes)
                                    .spawnRestriction(SpawnLocationTypes.ON_GROUND, Heightmap.Type.MOTION_BLOCKING_NO_LEAVES, GhostEntity::canSpawn))
                    .dimensions(0.6F, 1.8F).makeFireImmune());

    public static final EntityType<VampireEntity> VAMPIRE = register("vampire",
            FabricEntityType.Builder.createMob(VampireEntity::new, SpawnGroup.MONSTER,
                            mob -> mob.defaultAttributes(VampireEntity::createAttributes)
                                    .spawnRestriction(SpawnLocationTypes.ON_GROUND, Heightmap.Type.MOTION_BLOCKING_NO_LEAVES, VampireEntity::canSpawn))
                    .dimensions(0.6F, 1.95F));

    public static final EntityType<WerewolfEntity> WEREWOLF = register("werewolf",
            FabricEntityType.Builder.createMob(WerewolfEntity::new, SpawnGroup.MONSTER,
                            mob -> mob.defaultAttributes(WerewolfEntity::createAttributes)
                                    .spawnRestriction(SpawnLocationTypes.ON_GROUND, Heightmap.Type.MOTION_BLOCKING_NO_LEAVES, WerewolfEntity::canSpawn))
                    .dimensions(0.8F, 2.8F));

    public static final EntityType<HellhoundEntity> HELLHOUND = register("hellhound",
            FabricEntityType.Builder.createMob(HellhoundEntity::new, SpawnGroup.MONSTER,
                            mob -> mob.defaultAttributes(HellhoundEntity::createAttributes)
                                    .spawnRestriction(SpawnLocationTypes.ON_GROUND, Heightmap.Type.MOTION_BLOCKING_NO_LEAVES, HellhoundEntity::canSpawn))
                    .dimensions(0.6F, 0.85F).makeFireImmune());

    public static final EntityType<DemonEntity> DEMON = register("demon",
            FabricEntityType.Builder.createMob(DemonEntity::new, SpawnGroup.MONSTER,
                            mob -> mob.defaultAttributes(DemonEntity::createAttributes))
                    .dimensions(0.8F, 2.4F).makeFireImmune());

    public static final EntityType<LeonardEntity> LEONARD = register("leonard",
            FabricEntityType.Builder.createMob(LeonardEntity::new, SpawnGroup.MONSTER,
                            mob -> mob.defaultAttributes(LeonardEntity::createAttributes))
                    .dimensions(0.8F, 2.8F).makeFireImmune());

    public static final EntityType<BaphometEntity> BAPHOMET = register("baphomet",
            FabricEntityType.Builder.createMob(BaphometEntity::new, SpawnGroup.MONSTER,
                            mob -> mob.defaultAttributes(BaphometEntity::createAttributes))
                    .dimensions(0.8F, 2.8F).makeFireImmune());

    public static final EntityType<LilithEntity> LILITH = register("lilith",
            FabricEntityType.Builder.createMob(LilithEntity::new, SpawnGroup.MONSTER,
                            mob -> mob.defaultAttributes(LilithEntity::createAttributes))
                    .dimensions(0.8F, 2.8F).makeFireImmune());

    public static final EntityType<HerneEntity> HERNE = register("herne",
            FabricEntityType.Builder.createMob(HerneEntity::new, SpawnGroup.MONSTER,
                            mob -> mob.defaultAttributes(HerneEntity::createAttributes))
                    .dimensions(0.8F, 2.8F).makeFireImmune());

    private static <T extends net.minecraft.entity.Entity> EntityType<T> register(String path, EntityType.Builder<T> builder) {
        return Registry.register(Registries.ENTITY_TYPE, Bewitchment.id(path), builder.build(Bewitchment.id(path).toString()));
    }

    public static void init() {}
}
