package moriyashiine.bewitchment.common.entity.living;
import net.minecraft.sound.SoundEvents;

import moriyashiine.bewitchment.common.entity.living.util.BWBossEntity;
import moriyashiine.bewitchment.common.registry.*;
import net.minecraft.entity.*;
import net.minecraft.entity.attribute.*;
import net.minecraft.entity.effect.*;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.projectile.PersistentProjectileEntity;
import net.minecraft.entity.projectile.ArrowEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundEvent;
import net.minecraft.world.BossBar;
import net.minecraft.world.World;

public class HerneEntity extends BWBossEntity {
    public HerneEntity(EntityType<? extends HerneEntity> type,World world){super(type,world,BossBar.Color.GREEN);}
    public static DefaultAttributeContainer.Builder createAttributes(){return HostileEntity.createHostileAttributes().add(EntityAttributes.GENERIC_MAX_HEALTH,500).add(EntityAttributes.GENERIC_ATTACK_DAMAGE,24).add(EntityAttributes.GENERIC_ARMOR,10).add(EntityAttributes.GENERIC_MOVEMENT_SPEED,.3).add(EntityAttributes.GENERIC_KNOCKBACK_RESISTANCE,1).add(EntityAttributes.GENERIC_FOLLOW_RANGE,32);}
    @Override public int getVariants(){return 1;} @Override protected int getBossExperience(){return 75;} @Override protected int passiveHealInterval(){return 10;} @Override protected int rangedInterval(){return 80;} @Override protected int summonInterval(){return 600;} @Override protected int meleeFireSeconds(){return 16;}
    @Override protected void performRangedAttack(LivingEntity target){ArrowEntity spear=new ArrowEntity(getWorld(),this,new net.minecraft.item.ItemStack(BWObjects.HORNED_SPEAR),null);spear.setDamage(12);spear.setVelocity(target.getX()-getX(),target.getBodyY(.5)-getBodyY(.6),target.getZ()-getZ(),1.6F,2);getWorld().spawnEntity(spear);playSound(SoundEvents.ENTITY_GHAST_SHOOT,1,1);}
    @Override protected void summonMinions(ServerWorld world,LivingEntity target){for(int i=0;i<3;i++){WerewolfEntity w=BWEntityTypes.WEREWOLF.create(world);if(w!=null){w.refreshPositionAndAngles(getX()+random.nextInt(7)-3,getY(),getZ()+random.nextInt(7)-3,0,0);w.addStatusEffect(new StatusEffectInstance(StatusEffects.STRENGTH,1200,1));w.addStatusEffect(new StatusEffectInstance(StatusEffects.RESISTANCE,1200,1));w.addStatusEffect(new StatusEffectInstance(BWStatusEffects.HARDENING,1200,1));w.setTarget(target);world.spawnEntity(w);}}}
    @Override public boolean tryAttack(Entity target){boolean hit=super.tryAttack(target);if(hit&&target instanceof LivingEntity l)l.addStatusEffect(new StatusEffectInstance(BWStatusEffects.MORTAL_COIL,1200));return hit;}
    @Override public void setTarget(LivingEntity target){if(target!=null&&getWorld().isDay())target=null;super.setTarget(target);}
    @Override protected SoundEvent getAmbientSound(){return BWSounds.HERNE_AMBIENT;} @Override protected SoundEvent getHurtSound(net.minecraft.entity.damage.DamageSource s){return BWSounds.HERNE_HURT;} @Override protected SoundEvent getDeathSound(){return BWSounds.HERNE_DEATH;}
}
