package moriyashiine.bewitchment.common.entity.living.util;

import net.minecraft.entity.EntityData;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnReason;
import net.minecraft.entity.data.DataTracker;
import net.minecraft.entity.data.TrackedData;
import net.minecraft.entity.data.TrackedDataHandlerRegistry;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.server.world.ServerWorldAccess;
import net.minecraft.world.LocalDifficulty;
import net.minecraft.world.World;

public abstract class BWHostileEntity extends HostileEntity {
    private static final TrackedData<Integer> VARIANT = DataTracker.registerData(BWHostileEntity.class, TrackedDataHandlerRegistry.INTEGER);

    protected BWHostileEntity(EntityType<? extends HostileEntity> type, World world) {
        super(type, world);
    }

    @Override
    protected void initDataTracker(DataTracker.Builder builder) {
        super.initDataTracker(builder);
        builder.add(VARIANT, 1);
    }

    @Override
    public EntityData initialize(ServerWorldAccess world, LocalDifficulty difficulty, SpawnReason spawnReason, EntityData entityData) {
        EntityData result = super.initialize(world, difficulty, spawnReason, entityData);
        initializeVariant();
        return result;
    }

    protected void initializeVariant() {
        int variants = Math.max(1, getVariants());
        if (variants == 1) {
            setVariant(0);
        } else if (hasShiny() && random.nextInt(8192) == 0) {
            setVariant(0);
        } else if (hasShiny()) {
            setVariant(1 + random.nextInt(variants - 1));
        } else {
            setVariant(random.nextInt(variants));
        }
    }

    protected boolean hasShiny() {
        return false;
    }

    public abstract int getVariants();

    public int getVariant() {
        return dataTracker.get(VARIANT);
    }

    public void setVariant(int variant) {
        dataTracker.set(VARIANT, Math.max(0, Math.min(getVariants() - 1, variant)));
    }

    @Override
    public void writeCustomDataToNbt(NbtCompound nbt) {
        super.writeCustomDataToNbt(nbt);
        nbt.putInt("Variant", getVariant());
    }

    @Override
    public void readCustomDataFromNbt(NbtCompound nbt) {
        super.readCustomDataFromNbt(nbt);
        if (nbt.contains("Variant")) {
            setVariant(nbt.getInt("Variant"));
        }
    }
}
