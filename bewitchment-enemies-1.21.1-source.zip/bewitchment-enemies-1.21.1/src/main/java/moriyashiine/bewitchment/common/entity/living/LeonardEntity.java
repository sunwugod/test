package moriyashiine.bewitchment.common.entity.living;

import moriyashiine.bewitchment.common.entity.living.util.BWBossEntity;
import moriyashiine.bewitchment.common.registry.BWSounds;
import moriyashiine.bewitchment.common.registry.BWStatusEffects;
import net.minecraft.component.type.PotionContentsComponent;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.attribute.DefaultAttributeContainer;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.mob.WitchEntity;
import net.minecraft.entity.projectile.thrown.PotionEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.potion.Potions;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundEvent;
import net.minecraft.world.BossBar;
import net.minecraft.world.World;

public class LeonardEntity extends BWBossEntity {
    public LeonardEntity(EntityType<? extends LeonardEntity> type, World world) {
        super(type, world, BossBar.Color.PURPLE);
    }

    public static DefaultAttributeContainer.Builder createAttributes() {
        return HostileEntity.createHostileAttributes()
                .add(EntityAttributes.GENERIC_MAX_HEALTH, 375)
                .add(EntityAttributes.GENERIC_ATTACK_DAMAGE, 12)
                .add(EntityAttributes.GENERIC_ARMOR, 6)
                .add(EntityAttributes.GENERIC_MOVEMENT_SPEED, 0.25)
                .add(EntityAttributes.GENERIC_KNOCKBACK_RESISTANCE, 0.75)
                .add(EntityAttributes.GENERIC_FOLLOW_RANGE, 32);
    }

    @Override public int getVariants() { return 1; }
    @Override protected int rangedInterval() { return 40; }
    @Override protected int summonInterval() { return 600; }

    @Override
    protected void performRangedAttack(LivingEntity target) {
        ItemStack stack = PotionContentsComponent.createStack(Items.SPLASH_POTION, Potions.STRONG_HARMING);
        PotionEntity potion = new PotionEntity(getWorld(), this);
        potion.setItem(stack);
        double dx = target.getX() - getX();
        double dy = target.getEyeY() - 1.1D - potion.getY();
        double dz = target.getZ() - getZ();
        potion.setVelocity(dx, dy, dz, 0.75F, 8.0F);
        getWorld().spawnEntity(potion);
        playSound(BWSounds.GENERIC_SHOOT, 1.0F, 1.0F);
    }

    @Override
    protected void summonMinions(ServerWorld world, LivingEntity target) {
        for (int i = 0; i < 3; i++) {
            WitchEntity witch = EntityType.WITCH.create(world);
            if (witch != null) {
                witch.refreshPositionAndAngles(getX() + random.nextInt(7) - 3, getY(), getZ() + random.nextInt(7) - 3, random.nextFloat() * 360.0F, 0.0F);
                witch.addStatusEffect(new StatusEffectInstance(StatusEffects.RESISTANCE, 1200, 1));
                witch.addStatusEffect(new StatusEffectInstance(BWStatusEffects.HARDENING, 1200, 1));
                witch.setTarget(target);
                world.spawnEntity(witch);
            }
        }
    }

    @Override protected SoundEvent getAmbientSound() { return BWSounds.LEONARD_AMBIENT; }
    @Override protected SoundEvent getHurtSound(net.minecraft.entity.damage.DamageSource source) { return BWSounds.LEONARD_HURT; }
    @Override protected SoundEvent getDeathSound() { return BWSounds.LEONARD_DEATH; }
}
