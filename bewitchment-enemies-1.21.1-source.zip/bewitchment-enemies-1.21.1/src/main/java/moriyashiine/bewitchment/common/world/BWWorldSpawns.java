package moriyashiine.bewitchment.common.world;

import moriyashiine.bewitchment.common.registry.BWEntityTypes;
import net.fabricmc.fabric.api.biome.v1.BiomeModifications;
import net.fabricmc.fabric.api.biome.v1.BiomeSelectors;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnGroup;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.registry.RegistryKey;
import net.minecraft.world.biome.Biome;
import net.minecraft.world.biome.BiomeKeys;

public final class BWWorldSpawns {
    private BWWorldSpawns() {}

    public static void init() {
        // The four original natural supernatural spawns. Demon/boss entities are deliberately command/spawn-egg only.
        BiomeModifications.addSpawn(BiomeSelectors.foundInOverworld(), SpawnGroup.MONSTER, BWEntityTypes.GHOST, 20, 1, 1);
        add(20, BWEntityTypes.VAMPIRE,
                BiomeKeys.PLAINS, BiomeKeys.SUNFLOWER_PLAINS,
                BiomeKeys.TAIGA, BiomeKeys.SNOWY_TAIGA,
                BiomeKeys.OLD_GROWTH_PINE_TAIGA, BiomeKeys.OLD_GROWTH_SPRUCE_TAIGA);
        add(20, BWEntityTypes.WEREWOLF,
                BiomeKeys.FOREST, BiomeKeys.FLOWER_FOREST, BiomeKeys.BIRCH_FOREST,
                BiomeKeys.OLD_GROWTH_BIRCH_FOREST, BiomeKeys.DARK_FOREST,
                BiomeKeys.TAIGA, BiomeKeys.SNOWY_TAIGA,
                BiomeKeys.OLD_GROWTH_PINE_TAIGA, BiomeKeys.OLD_GROWTH_SPRUCE_TAIGA);
        add(6, BWEntityTypes.HELLHOUND, BiomeKeys.NETHER_WASTES, BiomeKeys.CRIMSON_FOREST);
    }

    @SafeVarargs
    private static void add(int weight, EntityType<? extends MobEntity> type, RegistryKey<Biome>... biomes) {
        BiomeModifications.addSpawn(BiomeSelectors.includeByKey(biomes), SpawnGroup.MONSTER, type, weight, 1, 1);
    }
}
