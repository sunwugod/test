package moriyashiine.bewitchment.client.model.entity.living;

import moriyashiine.bewitchment.common.entity.living.WerewolfEntity;
import net.minecraft.client.model.*;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.entity.model.BipedEntityModel;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Arm;
import net.minecraft.util.math.MathHelper;

public class WerewolfEntityModel<T extends WerewolfEntity> extends BipedEntityModel<T> {
    private final ModelPart realBody, tail01, bipedLeftLeg, bipedRightLeg, neck, lArm01, rArm01;
    private boolean realArm;

    public WerewolfEntityModel(ModelPart root) {
        super(root);
        realBody = root.getChild("realBody");
        ModelPart stomach = realBody.getChild("stomach");
        tail01 = stomach.getChild("tail01");
        bipedLeftLeg = stomach.getChild("BipedLeftLeg");
        bipedRightLeg = stomach.getChild("BipedRightLeg");
        neck = root.getChild("neck");
        lArm01 = root.getChild("lArm01");
        rArm01 = root.getChild("rArm01");
    }

    public static TexturedModelData getTexturedModelData() {
        ModelData data = BipedEntityModel.getModelData(Dilation.NONE, 0);
        ModelPartData root = data.getRoot();
        ModelPartData realBody = root.addChild("realBody", ModelPartBuilder.create().uv(49,15).cuboid(-5.5F,-3.3F,-2,11,11,8), ModelTransform.of(0,0,0,.5672F,0,0));
        realBody.addChild("realHead", ModelPartBuilder.create().uv(1,2).cuboid(-.5F,.7F,-.4F,1,1,1), ModelTransform.of(0,-2,2,0,0,0));
        ModelPartData stomach = realBody.addChild("stomach", ModelPartBuilder.create().uv(16,16).cuboid(-5,0,-3,10,12,6), ModelTransform.of(0,6.9F,2.6F,-.3927F,0,0));
        ModelPartData tail01 = stomach.addChild("tail01", ModelPartBuilder.create().uv(112,18).cuboid(-1.5F,0,-1.5F,3,4,3), ModelTransform.of(0,8.6F,2,.1047F,0,0));
        ModelPartData tail02 = tail01.addChild("tail02", ModelPartBuilder.create().uv(111,26).cuboid(-2,0,-2,4,7,4), ModelTransform.of(0,3.7F,0,-.2094F,0,0));
        ModelPartData tail03 = tail02.addChild("tail03", ModelPartBuilder.create().uv(112,40).cuboid(-1.5F,.2F,-1.5F,3,4,3), ModelTransform.of(0,6.5F,.1F,.1396F,0,0));
        tail03.addChild("tail04", ModelPartBuilder.create().uv(116,7).cuboid(-1,0,-1,2,7,2), ModelTransform.of(0,0,.4F,.0698F,0,0));
        stomach.addChild("fur06", ModelPartBuilder.create().uv(90,52).cuboid(-2,-1,0,4,5,2), ModelTransform.of(0,6.6F,1.5F,.6981F,0,0));
        stomach.addChild("fur05", ModelPartBuilder.create().uv(90,43).cuboid(-2,-1,0,4,5,2), ModelTransform.of(0,4.7F,1.6F,.6981F,0,0));

        ModelPartData leftLeg = stomach.addChild("BipedLeftLeg", ModelPartBuilder.create().uv(11,46).cuboid(-2.3F,-1.1F,-1.9F,5,13,5), ModelTransform.of(2.7F,10.2F,-.4F,0,0,0));
        ModelPartData ll2 = leftLeg.addChild("lLeg02", ModelPartBuilder.create().uv(0,35).cuboid(-2.01F,.4F,-2,4,7,4), ModelTransform.of(0,9.8F,.5F,1.309F,-.0524F,0));
        ModelPartData ll3 = ll2.addChild("lLeg03", ModelPartBuilder.create().uv(0,22).cuboid(-1.5F,0,-1.5F,3,10,3), ModelTransform.of(0,5.9F,.8F,-.7854F,0,.0873F));
        ModelPartData lf = ll3.addChild("lFoot", ModelPartBuilder.create().uv(0,14).cuboid(-2,0,-2.8F,4,2,5), ModelTransform.of(0,8.7F,-1.2F,.1309F,.0436F,-.0087F));
        lf.addChild("lFootClaw01", ModelPartBuilder.create().uv(1,48).cuboid(-.5F,-.5F,-1.7F,1,2,3), ModelTransform.of(-1.3F,.5F,-2.6F,.2269F,.1047F,0));
        lf.addChild("lFootClaw02", ModelPartBuilder.create().uv(1,48).cuboid(-.5F,-.5F,-1.7F,1,2,3), ModelTransform.of(0,.5F,-2.6F,.2269F,0,0));
        lf.addChild("lFootClaw03", ModelPartBuilder.create().uv(1,48).cuboid(-.5F,-.5F,-1.7F,1,2,3), ModelTransform.of(1.3F,.5F,-2.6F,.2269F,-.1047F,0));

        ModelPartData rightLeg = stomach.addChild("BipedRightLeg", ModelPartBuilder.create().uv(11,46).mirrored(true).cuboid(-2.7F,-1.1F,-1.9F,5,13,5), ModelTransform.of(-2.7F,10.2F,-.4F,0,0,0));
        ModelPartData rl2 = rightLeg.addChild("rLeg02", ModelPartBuilder.create().uv(0,35).mirrored(true).cuboid(-1.99F,.4F,-2,4,7,4), ModelTransform.of(0,9.8F,.5F,1.309F,.0524F,0));
        ModelPartData rl3 = rl2.addChild("rLeg03", ModelPartBuilder.create().uv(0,22).mirrored(true).cuboid(-1.5F,0,-1.5F,3,10,3), ModelTransform.of(0,5.9F,.8F,-.7854F,0,-.0873F));
        ModelPartData rf = rl3.addChild("rFoot", ModelPartBuilder.create().uv(0,14).mirrored(true).cuboid(-2,0,-2.8F,4,2,5), ModelTransform.of(0,8.7F,-1.2F,.1309F,-.0436F,.0087F));
        rf.addChild("rFootClaw01", ModelPartBuilder.create().uv(1,48).mirrored(true).cuboid(-.5F,-.5F,-1.7F,1,2,3), ModelTransform.of(1.3F,.5F,-2.6F,.2269F,-.1047F,0));
        rf.addChild("rFootClaw02", ModelPartBuilder.create().uv(1,48).mirrored(true).cuboid(-.5F,-.5F,-1.7F,1,2,3), ModelTransform.of(0,.5F,-2.6F,.2269F,0,0));
        rf.addChild("rFootClaw03", ModelPartBuilder.create().uv(1,48).mirrored(true).cuboid(-.5F,-.5F,-1.7F,1,2,3), ModelTransform.of(-1.3F,.5F,-2.6F,.2269F,.1047F,0));

        realBody.addChild("fur04", ModelPartBuilder.create().uv(90,35).cuboid(-2.5F,1,0,5,4,2), ModelTransform.of(0,-.3F,4.9F,.4363F,0,0));
        realBody.addChild("fur03", ModelPartBuilder.create().uv(90,24).cuboid(-4,0,-1,8,7,2), ModelTransform.of(0,-2.6F,4.5F,.6807F,0,0));
        realBody.addChild("fur02", ModelPartBuilder.create().uv(90,11).cuboid(-5,-1,-1,10,8,2), ModelTransform.of(0,-4.7F,3.4F,.8727F,0,0));

        ModelPartData la = root.addChild("lArm01", ModelPartBuilder.create().uv(32,47).cuboid(-2,0,-2,4,12,4), ModelTransform.NONE);
        ModelPartData la2 = la.addChild("lArm02", ModelPartBuilder.create().uv(49,46).cuboid(-1.5F,-1,-1.5F,3,13,3), ModelTransform.of(0,11.5F,0,-.5236F,0,.1484F));
        la2.addChild("lArmFur", ModelPartBuilder.create().uv(62,50).cuboid(-.5F,-.5F,1.5F,1,8,4), ModelTransform.of(.4F,-4,0,-.4363F,.0873F,.0873F));
        ModelPartData lc = la2.addChild("lClawJoint", ModelPartBuilder.create().cuboid(-.4F,1.5F,-.5F,1,1,1), ModelTransform.of(0,8.6F,0,0,0,0));
        lc.addChild("lClaw01", ModelPartBuilder.create().uv(27,0).cuboid(-1.4F,1.2F,-1.6F,2,5,1), ModelTransform.of(1,.2F,0,-.1047F,0,.2269F));
        lc.addChild("lClaw02", ModelPartBuilder.create().uv(27,0).cuboid(-1.4F,1.2F,-.5F,2,5,1), ModelTransform.of(1,.2F,-.1F,0,0,.2269F));
        lc.addChild("lClaw03", ModelPartBuilder.create().uv(27,0).cuboid(-1.4F,1.2F,-.5F,2,5,1), ModelTransform.of(1,.2F,.8F,.1047F,0,.2269F));

        ModelPartData ra = root.addChild("rArm01", ModelPartBuilder.create().uv(32,47).mirrored(true).cuboid(-2,0,-2,4,12,4), ModelTransform.NONE);
        ModelPartData ra2 = ra.addChild("rArm02", ModelPartBuilder.create().uv(49,46).mirrored(true).cuboid(-1.5F,-1,-1.5F,3,13,3), ModelTransform.of(0,11.5F,0,-.5236F,0,-.1484F));
        ra2.addChild("rArmFur", ModelPartBuilder.create().uv(62,50).mirrored(true).cuboid(-.5F,-.5F,1.5F,1,8,4), ModelTransform.of(-.4F,-4,0,-.4363F,-.0873F,-.0873F));
        ModelPartData rc = ra2.addChild("rClawJoint", ModelPartBuilder.create().mirrored(true).cuboid(-.6F,1.5F,-.5F,1,1,1), ModelTransform.of(0,8.6F,0,0,0,0));
        rc.addChild("rClaw01", ModelPartBuilder.create().uv(27,0).mirrored(true).cuboid(-.6F,1.2F,-1.6F,2,5,1), ModelTransform.of(-1,.2F,0,-.1047F,0,-.2269F));
        rc.addChild("rClaw02", ModelPartBuilder.create().uv(27,0).mirrored(true).cuboid(-.6F,1.2F,-.5F,2,5,1), ModelTransform.of(-1,.2F,-.1F,0,0,-.2269F));
        rc.addChild("rClaw03", ModelPartBuilder.create().uv(27,0).mirrored(true).cuboid(-.6F,1.2F,-.5F,2,5,1), ModelTransform.of(-1,.2F,.8F,.1047F,0,-.2269F));

        ModelPartData neck = root.addChild("neck", ModelPartBuilder.create().cuboid(-3.5F,-1.5F,-1,7,5,5), ModelTransform.of(0,0,0,-.2531F,0,0));
        ModelPartData head = neck.addChild("realHead2", ModelPartBuilder.create().uv(44,0).cuboid(-4,-3,-4.4F,8,6,7), ModelTransform.of(0,-.5F,-3.6F,1.9199F,0,0));
        ModelPartData jul = head.addChild("jawUpperLeft", ModelPartBuilder.create().uv(20,36).cuboid(-1,-2,-2,2,5,2), ModelTransform.of(1.2F,-5.1F,-1.5F,0,0,-.1396F));
        jul.addChild("upperTeethLeft01", ModelPartBuilder.create().uv(56,37).cuboid(-.5F,1,-1.8F,1,4,2), ModelTransform.of(.4F,-2.8F,-1,0,0,0));
        jul.addChild("upperTeethLeft02", ModelPartBuilder.create().uv(63,38).cuboid(-2.27F,1.4F,-1.4F,3,0,1), ModelTransform.of(0,-3.2F,-1,0,0,.1367F));
        ModelPartData jur = head.addChild("jawUpperRight", ModelPartBuilder.create().uv(20,36).mirrored(true).cuboid(-1,-2,-2,2,5,2), ModelTransform.of(-1.2F,-5.1F,-1.5F,0,0,.1396F));
        jur.addChild("upperTeethRight", ModelPartBuilder.create().uv(56,37).mirrored(true).cuboid(-.5F,1,-1.8F,1,4,2), ModelTransform.of(-.4F,-2.8F,-1,0,0,0));
        ModelPartData jaw = head.addChild("jawLower", ModelPartBuilder.create().uv(39,37).cuboid(-2,-2.9F,-1.5F,4,5,1), ModelTransform.of(0,-4.1F,-3,0,0,0));
        ModelPartData lt = jaw.addChild("lowerTeeth01", ModelPartBuilder.create().uv(63,41).cuboid(-1.6F,1.3F,-.6F,1,3,1), ModelTransform.of(0,-3.7F,.1F,0,0,0));
        lt.addChild("lowerTeeth02", ModelPartBuilder.create().uv(63,41).cuboid(.6F,1.3F,-.7F,1,3,1), ModelTransform.NONE);
        ModelPartData le = head.addChild("lEar01", ModelPartBuilder.create().uv(70,0).mirrored(true).cuboid(0,-1,-1.6F,1,3,2), ModelTransform.of(2.8F,-.1F,2.8F,.6981F,.1222F,-.6981F));
        le.addChild("lEar02", ModelPartBuilder.create().uv(78,0).mirrored(true).cuboid(-1.4F,2,-1.4F,1,5,1), ModelTransform.of(-.3F,-3,-.5F,.2269F,0,-.2618F));
        ModelPartData re = head.addChild("rEar01", ModelPartBuilder.create().uv(70,0).cuboid(-1,-1,-1.6F,1,3,2), ModelTransform.of(-2.8F,-.1F,2.8F,.6981F,-.1222F,.6981F));
        re.addChild("rEar02", ModelPartBuilder.create().uv(78,0).cuboid(.4F,2,-1.4F,1,5,1), ModelTransform.of(.3F,-3,-.5F,.2269F,0,.2618F));
        head.addChild("lCheekFur", ModelPartBuilder.create().uv(26,4).mirrored(true).cuboid(0,-.8F,-3.3F,0,6,5), ModelTransform.of(3.5F,-.5F,-.6F,.1222F,-.0873F,-.5236F));
        head.addChild("rCheekFur", ModelPartBuilder.create().uv(26,4).cuboid(0,-.8F,-3.3F,0,6,5), ModelTransform.of(-3.5F,-.5F,-.6F,.1222F,.0873F,.5236F));
        head.addChild("snout", ModelPartBuilder.create().uv(29,35).cuboid(-1.5F,-3.2F,-2,3,5,2), ModelTransform.of(0,-4.2F,-.1F,.182F,0,0));
        neck.addChild("fur01", ModelPartBuilder.create().uv(90,0).cuboid(-3.5F,2,0,7,7,2,new Dilation(.1F)), ModelTransform.of(0,0,-2.9F,1.7453F,0,0));
        return TexturedModelData.of(data,128,64);
    }

    @Override public void setAngles(T entity,float limbAngle,float limbDistance,float animationProgress,float headYaw,float headPitch) {
        realArm=false; super.setAngles(entity,limbAngle,limbDistance,animationProgress,headYaw,headPitch); realArm=true;
        copyRotation(neck,super.head); neck.setPivot(0,-18.2F,-1); neck.pitch-=.2531F;
        copyRotation(realBody,super.body); realBody.setPivot(0,-12.7F,0); realBody.pitch+=.5672F;
        copyRotation(lArm01,super.leftArm); lArm01.setPivot(5.5F,-15,2); lArm01.pitch+=.1745F; lArm01.yaw-=.0873F; lArm01.roll-=.2356F;
        copyRotation(rArm01,super.rightArm); rArm01.setPivot(-5.5F,-15,2); rArm01.pitch+=.1745F; rArm01.yaw+=.0873F; rArm01.roll+=.2356F;
        copyRotation(bipedLeftLeg,super.leftLeg); bipedLeftLeg.pitch/=2; bipedLeftLeg.pitch-=.75F; bipedLeftLeg.yaw-=.2269F; bipedLeftLeg.roll-=.0873F;
        copyRotation(bipedRightLeg,super.rightLeg); bipedRightLeg.pitch/=2; bipedRightLeg.pitch-=.75F; bipedRightLeg.yaw+=.2269F; bipedRightLeg.roll+=.0873F;
        tail01.roll=MathHelper.sin(animationProgress/8F)/8F;
        if(entity.isSneaking()){neck.pivotY+=2;neck.pivotZ-=4;realBody.pivotY+=2;realBody.pivotZ-=4;realBody.pitch+=.5F;lArm01.pivotY+=2;lArm01.pivotZ-=4;rArm01.pivotY+=2;rArm01.pivotZ-=4;bipedLeftLeg.pitch-=.5F;bipedRightLeg.pitch-=.5F;}
    }
    @Override public void render(MatrixStack matrices,VertexConsumer vertices,int light,int overlay,int color){neck.render(matrices,vertices,light,overlay,color);realBody.render(matrices,vertices,light,overlay,color);lArm01.render(matrices,vertices,light,overlay,color);rArm01.render(matrices,vertices,light,overlay,color);}
    @Override protected ModelPart getArm(Arm arm){return realArm?(arm==Arm.LEFT?lArm01:rArm01):super.getArm(arm);}
    private static void copyRotation(ModelPart to,ModelPart from){to.pitch=from.pitch;to.yaw=from.yaw;to.roll=from.roll;}
}
