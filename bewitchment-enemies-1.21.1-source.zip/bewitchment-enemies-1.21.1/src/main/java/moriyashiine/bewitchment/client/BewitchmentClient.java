package moriyashiine.bewitchment.client;

import moriyashiine.bewitchment.Bewitchment;
import moriyashiine.bewitchment.client.model.entity.living.*;
import moriyashiine.bewitchment.client.render.entity.living.*;
import moriyashiine.bewitchment.common.registry.BWEntityTypes;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.rendering.v1.EntityModelLayerRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;
import net.minecraft.client.render.entity.model.EntityModelLayer;

public class BewitchmentClient implements ClientModInitializer {
    public static final EntityModelLayer GHOST_LAYER=layer("ghost"),VAMPIRE_LAYER=layer("vampire"),WEREWOLF_LAYER=layer("werewolf"),HELLHOUND_LAYER=layer("hellhound"),DEMON_MALE_LAYER=layer("demon_male"),DEMON_FEMALE_LAYER=layer("demon_female"),LEONARD_LAYER=layer("leonard"),BAPHOMET_LAYER=layer("baphomet"),LILITH_LAYER=layer("lilith"),HERNE_LAYER=layer("herne");
    private static EntityModelLayer layer(String id){return new EntityModelLayer(Bewitchment.id(id),"main");}
    @Override public void onInitializeClient(){
        EntityModelLayerRegistry.registerModelLayer(GHOST_LAYER,GhostEntityModel::getTexturedModelData);EntityModelLayerRegistry.registerModelLayer(VAMPIRE_LAYER,VampireEntityModel::getTexturedModelData);EntityModelLayerRegistry.registerModelLayer(WEREWOLF_LAYER,WerewolfEntityModel::getTexturedModelData);EntityModelLayerRegistry.registerModelLayer(HELLHOUND_LAYER,HellhoundEntityModel::getTexturedModelData);
        EntityModelLayerRegistry.registerModelLayer(DEMON_MALE_LAYER,DemonEntityModel::getTexturedModelData);EntityModelLayerRegistry.registerModelLayer(DEMON_FEMALE_LAYER,DemonEntityModel::getTexturedModelData);EntityModelLayerRegistry.registerModelLayer(LEONARD_LAYER,LeonardEntityModel::getTexturedModelData);EntityModelLayerRegistry.registerModelLayer(BAPHOMET_LAYER,BaphometEntityModel::getTexturedModelData);EntityModelLayerRegistry.registerModelLayer(LILITH_LAYER,LilithEntityModel::getTexturedModelData);EntityModelLayerRegistry.registerModelLayer(HERNE_LAYER,HerneEntityModel::getTexturedModelData);
        EntityRendererRegistry.register(BWEntityTypes.GHOST,c->new EnemyRenderer<>(c,new GhostEntityModel<>(c.getPart(GHOST_LAYER)),.35F,"living/ghost",5));
        EntityRendererRegistry.register(BWEntityTypes.VAMPIRE,c->new EnemyRenderer<>(c,new VampireEntityModel<>(c.getPart(VAMPIRE_LAYER)),.5F,"living/vampire",2));
        EntityRendererRegistry.register(BWEntityTypes.WEREWOLF,c->new EnemyRenderer<>(c,new WerewolfEntityModel<>(c.getPart(WEREWOLF_LAYER)),.7F,"living/werewolf",7));
        EntityRendererRegistry.register(BWEntityTypes.HELLHOUND,c->new EnemyRenderer<>(c,new HellhoundEntityModel<>(c.getPart(HELLHOUND_LAYER)),.5F,"living/hellhound",5));
        EntityRendererRegistry.register(BWEntityTypes.DEMON,DemonEntityRenderer::new);
        EntityRendererRegistry.register(BWEntityTypes.LEONARD,c->new EnemyRenderer<>(c,new LeonardEntityModel<>(c.getPart(LEONARD_LAYER)),.7F,"living/leonard",1));
        EntityRendererRegistry.register(BWEntityTypes.BAPHOMET,c->new EnemyRenderer<>(c,new BaphometEntityModel<>(c.getPart(BAPHOMET_LAYER)),.7F,"living/baphomet/baphomet",1));
        EntityRendererRegistry.register(BWEntityTypes.LILITH,c->new EnemyRenderer<>(c,new LilithEntityModel<>(c.getPart(LILITH_LAYER)),.7F,"living/lilith",1));
        EntityRendererRegistry.register(BWEntityTypes.HERNE,c->new EnemyRenderer<>(c,new HerneEntityModel<>(c.getPart(HERNE_LAYER)),.7F,"living/herne",1));
    }
}
