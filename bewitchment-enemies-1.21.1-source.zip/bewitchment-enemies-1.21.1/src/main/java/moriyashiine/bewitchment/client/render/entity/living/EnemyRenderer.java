package moriyashiine.bewitchment.client.render.entity.living;

import moriyashiine.bewitchment.Bewitchment;
import moriyashiine.bewitchment.common.entity.living.util.BWHostileEntity;
import net.minecraft.client.render.entity.EntityRendererFactory;
import net.minecraft.client.render.entity.MobEntityRenderer;
import net.minecraft.client.render.entity.model.EntityModel;
import net.minecraft.util.Identifier;

public class EnemyRenderer<T extends BWHostileEntity, M extends EntityModel<T>> extends MobEntityRenderer<T,M> {
    private final String path;
    private final int textures;
    public EnemyRenderer(EntityRendererFactory.Context ctx,M model,float shadow,String path,int textures){super(ctx,model,shadow);this.path=path;this.textures=textures;}
    @Override public Identifier getTexture(T entity){int v=Math.max(0,Math.min(textures-1,entity.getVariant()));return Bewitchment.id("textures/entity/"+path+(textures>1?"/"+v:"")+".png");}
}
