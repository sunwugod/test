package moriyashiine.bewitchment.client.model.entity.living;
import moriyashiine.bewitchment.common.entity.living.GhostEntity;
import net.minecraft.client.model.*;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.entity.model.BipedEntityModel;
import net.minecraft.client.render.entity.model.CrossbowPosing;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Arm;
import net.minecraft.util.math.MathHelper;
public class GhostEntityModel<T extends GhostEntity> extends BipedEntityModel<T> {
 private final ModelPart realBody,realBodyTrail00,BipedLeftArm,BipedRightArm,realHead; private boolean realArm=false;
 public GhostEntityModel(ModelPart root){super(root);realBody=root.getChild("realBody");realBodyTrail00=realBody.getChild("realBodyTrail00");BipedLeftArm=root.getChild("BipedLeftArm");BipedRightArm=root.getChild("BipedRightArm");realHead=root.getChild("realHead");}
 public static TexturedModelData getTexturedModelData(){ModelData data=BipedEntityModel.getModelData(Dilation.NONE,0);ModelPartData root=data.getRoot();ModelPartData ra=root.addChild("BipedRightArm",ModelPartBuilder.create().uv(40,16).mirrored(true).cuboid(-3,-2,-2,4,13,4),ModelTransform.of(-5,2,0,-1.3963F,0,.1F));ra.addChild("rArmWisp",ModelPartBuilder.create().uv(40,34).mirrored(true).cuboid(-1.5F,-4.5F,.1F,3,11,4),ModelTransform.of(-1,2.7F,1.7F,0,0,0));ModelPartData head=root.addChild("realHead",ModelPartBuilder.create().cuboid(-4,-8,-4,8,8,8),ModelTransform.NONE);ModelPartData skull=head.addChild("skull",ModelPartBuilder.create().uv(34,0).cuboid(-3.5F,-7.5F,-3,7,5,6),ModelTransform.NONE);skull.addChild("skullJaw",ModelPartBuilder.create().uv(19,30).cuboid(-2.5F,-1,-3.5F,5,2,5),ModelTransform.of(0,-1.9F,.9F,.1745F,0,0));ModelPartData la=root.addChild("BipedLeftArm",ModelPartBuilder.create().uv(40,16).mirrored(true).cuboid(-1,-2,-2,4,13,4),ModelTransform.of(5,2,0,-1.3963F,0,-.1F));la.addChild("lArmWisp",ModelPartBuilder.create().uv(40,34).mirrored(true).cuboid(-1.5F,-4.5F,.1F,3,11,4),ModelTransform.of(1,2.7F,1.7F,0,0,0));ModelPartData body=root.addChild("realBody",ModelPartBuilder.create().uv(14,16).cuboid(-4,0,-2,8,8,4),ModelTransform.of(0,0,0,.2094F,0,0));ModelPartData trail=body.addChild("realBodyTrail00",ModelPartBuilder.create().uv(33,51).cuboid(-4.5F,0,-2.5F,9,6,5),ModelTransform.of(0,7.7F,0,.1047F,0,0));trail.addChild("realBodyTrail01",ModelPartBuilder.create().uv(0,39).cuboid(-5,0,-3,10,9,6),ModelTransform.of(0,5.8F,.1F,.1047F,0,0));return TexturedModelData.of(data,64,64);}
 @Override public void setAngles(T e,float la,float ld,float ap,float hy,float hp){realArm=false;super.setAngles(e,la,ld,ap,hy,hp);realArm=true;realHead.copyTransform(super.head);realBodyTrail00.pitch=MathHelper.sin(ap/12)/6;CrossbowPosing.meleeAttack(leftArm,rightArm,false,e.handSwingProgress,ap);if(e.getDataTracker().get(GhostEntity.HAS_TARGET)){rightArm.pitch+=4.5F;rightArm.roll=MathHelper.sin(ap)/2;leftArm.pitch+=4.5F;leftArm.roll=-rightArm.roll;}else{leftArm.roll=-.1F;rightArm.roll=.1F;}}
 @Override public void render(MatrixStack m,VertexConsumer v,int l,int o,int c){realHead.render(m,v,l,o,c);realBody.render(m,v,l,o,c);leftArm.render(m,v,l,o,c);rightArm.render(m,v,l,o,c);}
 @Override protected ModelPart getArm(Arm arm){return realArm?(arm==Arm.LEFT?BipedLeftArm:BipedRightArm):super.getArm(arm);}
}
