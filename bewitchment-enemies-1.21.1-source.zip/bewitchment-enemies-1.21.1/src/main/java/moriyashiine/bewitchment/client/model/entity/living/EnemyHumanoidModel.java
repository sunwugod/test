package moriyashiine.bewitchment.client.model.entity.living;

import net.minecraft.client.model.*;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.entity.model.BipedEntityModel;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.util.Arm;
import net.minecraft.util.math.MathHelper;

/** Small 1.21.1-safe base for the preserved custom boss meshes. */
abstract class EnemyHumanoidModel<T extends MobEntity> extends BipedEntityModel<T> {
    protected final ModelPart realHead, realBody, realLeftArm, realRightArm, realLeftLeg, realRightLeg;
    private boolean realArm;
    protected EnemyHumanoidModel(ModelPart root) {
        super(root);
        realHead=root.getChild("realHead"); realBody=root.getChild("realBody");
        realLeftArm=root.getChild("realLeftArm"); realRightArm=root.getChild("realRightArm");
        realLeftLeg=root.getChild("realLeftLeg"); realRightLeg=root.getChild("realRightLeg");
    }
    @Override public void setAngles(T e,float limbAngle,float limbDistance,float age,float yaw,float pitch){
        realArm=false; super.setAngles(e,limbAngle,limbDistance,age,yaw,pitch); realArm=true;
        copy(realHead,head); copy(realBody,body); copy(realLeftArm,leftArm); copy(realRightArm,rightArm); copy(realLeftLeg,leftLeg); copy(realRightLeg,rightLeg);
        animateExtra(e,limbAngle,limbDistance,age,yaw,pitch);
    }
    protected void animateExtra(T e,float limbAngle,float limbDistance,float age,float yaw,float pitch){}
    protected static void copy(ModelPart to,ModelPart from){to.pitch=from.pitch;to.yaw=from.yaw;to.roll=from.roll;}
    @Override public void render(MatrixStack matrices, VertexConsumer vertices,int light,int overlay,int color){realHead.render(matrices,vertices,light,overlay,color);realBody.render(matrices,vertices,light,overlay,color);realLeftArm.render(matrices,vertices,light,overlay,color);realRightArm.render(matrices,vertices,light,overlay,color);realLeftLeg.render(matrices,vertices,light,overlay,color);realRightLeg.render(matrices,vertices,light,overlay,color);}
    @Override protected ModelPart getArm(Arm arm){return realArm?(arm==Arm.LEFT?realLeftArm:realRightArm):super.getArm(arm);}
    protected static ModelPartData base(ModelData data,int texW,int texH,float yOffset){
        ModelPartData root=data.getRoot();
        root.addChild("realHead",ModelPartBuilder.create().uv(0,0).cuboid(-4,-8,-4,8,8,8),ModelTransform.of(0,yOffset,0,0,0,0));
        root.addChild("realBody",ModelPartBuilder.create().uv(16,16).cuboid(-4,0,-2,8,12,4),ModelTransform.of(0,yOffset,0,0,0,0));
        root.addChild("realLeftArm",ModelPartBuilder.create().uv(40,16).cuboid(-1,-2,-2,4,12,4),ModelTransform.of(5,yOffset+2,0,0,0,0));
        root.addChild("realRightArm",ModelPartBuilder.create().uv(40,16).mirrored(true).cuboid(-3,-2,-2,4,12,4),ModelTransform.of(-5,yOffset+2,0,0,0,0));
        root.addChild("realLeftLeg",ModelPartBuilder.create().uv(0,16).cuboid(-2,0,-2,4,12,4),ModelTransform.of(2,yOffset+12,0,0,0,0));
        root.addChild("realRightLeg",ModelPartBuilder.create().uv(0,16).mirrored(true).cuboid(-2,0,-2,4,12,4),ModelTransform.of(-2,yOffset+12,0,0,0,0));
        return root;
    }
    protected static void addSimpleHorns(ModelPartData head,int u,int v,float spread,float scale){
        ModelPartData lh=head.addChild("leftHorn",ModelPartBuilder.create().uv(u,v).cuboid(-scale,-5*scale,-scale,2*scale,5*scale,2*scale),ModelTransform.of(spread,-6,0,-.35F,0,.35F));
        lh.addChild("leftHornTip",ModelPartBuilder.create().uv(u,v).cuboid(-scale*.6F,-4*scale,-scale*.6F,1.2F*scale,4*scale,1.2F*scale),ModelTransform.of(0,-4*scale,0,-.4F,0,.2F));
        ModelPartData rh=head.addChild("rightHorn",ModelPartBuilder.create().uv(u,v).mirrored(true).cuboid(-scale,-5*scale,-scale,2*scale,5*scale,2*scale),ModelTransform.of(-spread,-6,0,-.35F,0,-.35F));
        rh.addChild("rightHornTip",ModelPartBuilder.create().uv(u,v).mirrored(true).cuboid(-scale*.6F,-4*scale,-scale*.6F,1.2F*scale,4*scale,1.2F*scale),ModelTransform.of(0,-4*scale,0,-.4F,0,-.2F));
    }
}
