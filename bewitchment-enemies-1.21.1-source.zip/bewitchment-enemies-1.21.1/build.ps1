$ErrorActionPreference = "Stop"
gradle build
