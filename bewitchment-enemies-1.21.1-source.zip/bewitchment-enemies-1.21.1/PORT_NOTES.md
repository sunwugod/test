# Port notes

## Natural spawning

- Ghost: Overworld monster spawn, weight 20, group 1.
- Vampire: plains/taiga families, weight 20, group 1; its spawn predicate additionally requires darkness, night, and new moon.
- Werewolf: forest/taiga families, weight 20, group 1; its spawn predicate additionally requires darkness, night, and full moon.
- Hellhound: Nether Wastes and Crimson Forest, weight 6, group 1.
- Demon, Leonard, Baphomet, Lilith and Herne are intentionally not injected into natural biome spawning. They remain accessible by spawn egg and `/summon`.

## Dependency reductions

The original 1.20.1 mod's unrelated systems and third-party gameplay dependencies were not carried forward. Vanilla/Fabric 1.21.1 facilities are used where possible. Werewolf step height uses the vanilla 1.21.1 step-height attribute. Vampire regeneration is self-contained rather than relying on the original blood-component subsystem.

## Mob-specific behavior

- Ghost: flying/phasing hostile; daylight removal; normal variants apply Hunger, Slowness, Corrosion or Sinking.
- Vampire: hostile to players and selected humanoids; new-moon-only natural spawn; daylight burning; simplified self-contained regeneration.
- Werewolf: high armor/damage; full-moon-only natural spawn; stores a villager representation and changes back after the full-moon/night condition ends.
- Hellhound: pounce/melee behavior; burning attacks; water vulnerability; Nether natural spawn.
- Demon: melee + fireball combat retained; merchant/contract behavior removed.
- Leonard: potion ranged combat and witch minions retained; ritual/progression hooks removed.
- Baphomet: fireball volleys and blaze minions retained; ritual/progression hooks removed.
- Lilith: wither-skull volleys and vampire minions retained; ritual/progression hooks removed.
- Herne: strong melee, ranged spear-like attack and werewolf minions retained; ritual/progression hooks removed.

## Known first-pass differences

1. The original boss acquisition/summoning systems are completely removed by request.
2. Herne currently uses an arrow-entity projectile carrying the retained Horned Spear item for its ranged attack. The dropped Horned Spear item/model is preserved, but the in-flight projectile does not yet use a dedicated spear renderer.
3. The four named boss models and Demon model are reconstructed for the 1.21.1 model API using the original textures and distinctive parts. They should be visually recognizable but are not guaranteed cube-for-cube identical to the 1.20.1 source models until an in-game comparison pass is done.
4. Loot tables preserve the relevant drops but omit some original looting-enchantment scaling in this first pass.
5. Because this environment cannot run a full Gradle/Fabric build, API compile errors may still require a small follow-up patch after the first local build/test.
